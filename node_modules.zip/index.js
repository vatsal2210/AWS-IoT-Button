var request = require('request');

exports.handler = function(event, context) {
	
	console.log('event ' , event.clickType);        
	var device_status = event.clickType == 'SINGLE' ? 1 : 0;
	
	console.log('device_status ' , device_status);
	
	var postData = {'action': 'lobby', 'device_status': device_status}

	var url = 'http://home.deepfoods.net:11113/groupAction'
	var options = {
		method: 'post',
		body: postData,
		json: true,
		url: url
	}
	
	request.post(options, function (err, res, body) {
		if (err) {
			console.error('error posting json: ', err)
			throw err
		}	 
		var headers = res.headers;
		var statusCode = res.statusCode;
	})
};